/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.tienda.domain;
@data

/**
 *
 * @author Laboratorios
 */
public class item extends Producto{
    private int cantidad;
    
    public item() {
    }
    
    public item(Producto producto) {
        public Item(Producto producto) {
        super.setActivo(producto.isActivo());
        super.setCategoria(producto.getCategoria());
        super.setDescripcion(producto.getDescripcion());
        super.setDetalle(producto.getDetalle());
        super.setExistencias(producto.getExistencias());
        super.setIdProducto(producto.getIdProducto());
        super.setPrecio(producto.getPrecio());
        super.setRutaImagen(producto.getRutaImagen());
        this.cantidad=0;
               
    }
    
    
}
