/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.tienda.domain;

import java.util.List;

/**
 *
 * @author Laboratorios
 */
public interface itemservices {
    List<item> listaitems = new arrayList<>();
    
    public list<item> gets();
    public item get(Item item);
    
    public void delete(Item item);
            
    public void save(Item item);
    
    public void actualiza(Item item);
    
    public void facturar();
            
            
}
